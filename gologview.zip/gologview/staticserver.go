package main

import (
	"github.com/xxl6097/gologview/assets"
	_ "github.com/xxl6097/gologview/assets/tcptest"
	"net/http"
	"regexp"
	"time"
)

var muxs map[string]func(http.ResponseWriter, *http.Request)

type Myhandler struct{}

const (
	Template_Dir = "./assets/tcptest/logview/"
)

func main() {
	assets.Load("")
	server := http.Server{
		Addr:        ":9999",
		Handler:     &Myhandler{},
		ReadTimeout: 10 * time.Second,
	}
	muxs = make(map[string]func(http.ResponseWriter, *http.Request))
	muxs["/"] = indexHtml
	server.ListenAndServe()
}

func (*Myhandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if h, ok := muxs[r.URL.String()]; ok {
		h(w, r)
		return
	}
	if ok, _ := regexp.MatchString("/css/", r.URL.String()); ok {
		//http.StripPrefix("/css/", http.FileServer(http.Dir("./logview/css/"))).ServeHTTP(w, r)
		http.StripPrefix("/css/", http.FileServer(assets.FileSystem)).ServeHTTP(w, r)
	} else if ok, _ := regexp.MatchString("/js/", r.URL.String()); ok {
		//http.StripPrefix("/js/", http.FileServer(http.Dir("./logview/js/"))).ServeHTTP(w, r)
		http.StripPrefix("/js/", http.FileServer(assets.FileSystem)).ServeHTTP(w, r)
	}
}

func indexHtml(w http.ResponseWriter, r *http.Request) {
	//t, _ := template.ParseFiles(Template_Dir + "index.html")
	//t.Execute(w, nil)

	http.StripPrefix("index.html", http.FileServer(assets.FileSystem)).ServeHTTP(w, r)
}
